from pyfiglet import Figlet
from tabulate import tabulate
import csv
import math
import random
import time


class WordGuesser:

    # Class variable 'words' that will store all the words of that particular length
    words = []

    # Class variable "headers" that will store the headers of the statistics.csv file
    headers = ["Total Games Played", "Total Wins", "Win Percentage", "Current Win Streak", "Longest Win Streak", "Fastest Win (in seconds)"]

    # Class variables "insideword" and "outsideword" that will store the correct and incorrect words
    insideword, outsideword = [], []

    # Class variable "guesses" that will store a list of dictionaries with each dictionary having the key "Guesses"
    guesses = []

    # Class variable "guesses_so_far" that stores the users' guesses
    guesses_so_far = []

    # Class variable "generated" that will store the generated word
    generated = None

    @classmethod
    def startup_menu(cls):
        f = Figlet(font="big")
        print(f.renderText('Welcome to WordGuesser!\n'))
        print("1: Start a game\n2: View player statistics\n3: How to play\n4: End programme\n")
        while True:
            option = input("Option: ")
            if option == "1" or option == "2" or option == "3" or option == "4":
                return option


    @classmethod
    # Get a random word with a variable number of letters
    def get_word(cls, number):
        # Start with an empty list
        cls.words.clear()
        # Clears list of guesses
        cls.guesses.clear()
        cls.guesses_so_far.clear()
        # Reading from the txt file with all the words in the dictionary
        with open("words.txt", "r") as file:
            for word in file:
                # Remove trailing newline and capitalises word
                word = word.rstrip().upper()
                # If word is n letters long
                if len(word) == number:
                    cls.words.append(word)
            # Instead of
            # words = [word.rstrip() for word in file if len(word.rstrip()) == 5]
            # because this use of list comprehension calls word.rstrip twice
        # If the list is empty after reading from the text fil
        if cls.words == []:
            raise IndexError("No word of that length exists")
        return random.choice(cls.words)


    @classmethod
    # Generate the number of guesses based on the number of letters
    # Adding a fixed base
    def generate_attempts(cls, length):
        # If length chosen is not valid
        if length < 2:
            raise ValueError("Invalid length of word")
        return round(length / 2 + 3)


    @classmethod
    # Validates user's guess
    def is_valid_guess(cls, guess, word):
        # Because cls.words only contains capitalised words
        guess = guess.upper()
        # If guessed word contains characters other than alphabets
        if not guess.isalpha():
            print("Guess must only contain alphabets.")
        # If guessed word does not exist
        elif guess not in cls.words:
            print(f"{guess} is not a valid word in the dictionary.")
        # If the guessed word is not the same length as the generated word
        elif len(guess) != len(word):
            print(f"Invalid number of letters in '{guess}'.")
        elif guess in cls.guesses_so_far:
            print(f"The word '{guess}' was already used for guessing.")
        else:
            cls.guesses_so_far.append(guess)
            return True
        return False


    @classmethod
    # Checks if word is guessed correctly
    def is_correct_guess(cls, guess, word):
        return guess == word


    @classmethod
    # Evaluates the guess according to the word
    def evaluate_guess(cls, guess, word):
        # Initialise the string that will be displayed after each guess
        display = ''
        for letter in zip(guess, word):
            # If i'th letter of guess matches i'th letter of word
            if letter[0] == letter[1]:
                display += "🟢"
                # Prevents multiple appearances of the same letter
                if letter[0] not in cls.insideword:
                    cls.insideword.append(letter[0])
            # If the i'th letter of guess is in the word
            elif letter[0] in word:
                display += "🟡"
                if letter[0] not in cls.insideword:
                    cls.insideword.append(letter[0])
            # If the i'th letter of guess is not in the word
            else:
                display += "🔴"
                if letter[0] not in cls.outsideword:
                    cls.outsideword.append(letter[0])

        # Appends a dictionary to the list with the key "Guesses"
        cls.guesses.append({"Guesses": f'{" " + " ".join(guess.upper())}\n{display}\n'})
        # Displays all the guesses and their evaluations
        print()
        for attempt in cls.guesses:
            for key in attempt:
                print(attempt[key])

        # Displays the guesses in a table
        # Note: single element-ed tuples need to have a comma
        # print(f"\n{tabulate(cls.guesses, headers="keys", tablefmt="grid", colalign=("center",))}\n")
        # the left padding of emojis is too big... not sure how to fix

        # Sort in alphabetical order
        cls.insideword.sort()
        cls.outsideword.sort()
        # Prints out correct and incorrect letters
        print(f"Letters in word: {', '.join(cls.insideword)}")
        print(f"Letters not in word: {', '.join(cls.outsideword)}")
        # Formatting
        print()
        return


    @classmethod
    # Validates if user wants to play another round
    def is_play_again(cls):
        # Clears the lists of correct and incorrect letters
        cls.insideword.clear()
        cls.outsideword.clear()
        while True:
            option = input("Play again? [Y/N] ").strip().lower()
            if option.startswith("y"):
                return True
            if option.startswith("n"):
                return False
            print("Y/N")


    @classmethod
    # Updates statistics if user wins
    def update_statistics(cls, outcome, time_taken=math.inf):
        # Initiates buffer to store the updated data from statistics.csv
        buffer = []
        with open("statistics.csv", "r") as file:
            reader = csv.DictReader(file)
            for row in reader:
                buffer.append(row)
            # If statistics.txt file is empty
            if not buffer:
                buffer.append({key: 0 for key in cls.headers})
                buffer[0]["Fastest Win"] = float(time_taken)
            else:
                # Convert dict values to ints
                for row in buffer:
                    for key in row:
                        if key == "Fastest Win (in seconds)":
                            # If this is the user's first game
                            if row[key] == "N/A":
                                row[key] = round(float(time_taken), 2)
                            else:
                                row[key] = float(row[key])
                        else:
                            row[key] = int(row[key])
            # If user wins games
            if outcome == "win":
                buffer[0]["Total Games Played"] += 1
                buffer[0]["Total Wins"] += 1
                buffer[0]["Win Percentage"] = round(buffer[0]["Total Wins"] / buffer[0]["Total Games Played"] * 100)
                buffer[0]["Current Win Streak"] += 1
                if buffer[0]["Current Win Streak"] > buffer[0]["Longest Win Streak"]:
                    buffer[0]["Longest Win Streak"] = buffer[0]["Current Win Streak"]
                if float(time_taken) < buffer[0]["Fastest Win (in seconds)"]:
                    buffer[0]["Fastest Win (in seconds)"] = round(float(time_taken), 2)
            # If user loses game
            elif outcome == "lose":
                buffer[0]["Total Games Played"] += 1
                buffer[0]["Win Percentage"] = round(buffer[0]["Total Wins"] / buffer[0]["Total Games Played"] * 100)
                buffer[0]["Current Win Streak"] = 0
            else:
                raise ValueError(f"Invalid outcome: {outcome}. Expected 'win' or 'lose'.")
        # Updates statistics.csv with the newest data
        with open("statistics.csv", "w") as file:
            writer = csv.DictWriter(file, fieldnames=cls.headers)
            writer.writeheader()
            writer.writerow(buffer[0])


    @classmethod
    # View statistics
    def view_statistics(cls):
        with open("statistics.csv", "r") as file:
            # Stores the data in a list of dictionaries in reader
            reader = csv.DictReader(file)

            f = Figlet(font="big")
            print(f.renderText('Statistics\n'))

            # Prints out the list of dictionaries in a table that has their keys as the headers and each statistic is centered within their column
            print(tabulate(reader, headers="keys", tablefmt="grid", colalign=("center", "center", "center", "center", "center", "center")))
            print("\n1: Back to main menu\n2: Reset statistics\n3: End programme\n")
            while True:
                option = input("Option: ")
                if option == "1" or option == "2" or option == "3":
                    return option


    @classmethod
    def reset_statistics(cls):
        with open("statistics.csv", "w") as file:
            writer = csv.DictWriter(file, fieldnames=cls.headers)
            writer.writeheader()
            row = {key: 0 for key in cls.headers}
            # Changing the fastest win column
            row["Fastest Win (in seconds)"] = "N/A"
            writer.writerow(row)


    @classmethod
    def start_game(cls):
        # Gets user input
        number = get_int("Number of letters: ")
        # Generate the number of guesses based on the number of letters
        attempts = WordGuesser.generate_attempts(number)

        # Game start notice
        print("Game starting...")
        time.sleep(1)
        f = Figlet(font="big")
        print(f.renderText('Game started!\n'))
        # Records start time
        start_time = time.time()

        # Get a randomly generated word of that length
        random.seed(50)
        word = WordGuesser.get_word(number)
        cls.generated = word
        # Vogue

        # Validates user's guess
        while True:
            guess = input("(restart: /restart | give up: /quit)\n\nGuess: ").strip().upper()
            # If user chooses to restart / quit programme
            WordGuesser.handle_exit(guess)

            # Processing pause to pace the game better
            WordGuesser.processing()

            # If the guessed word does not meet the requirements
            if not WordGuesser.is_valid_guess(guess, word):
                continue

            # If word is guessed correctly
            if WordGuesser.is_correct_guess(guess, word):
                WordGuesser.evaluate_guess(guess, word)
                # Record end time
                end_time = time.time()
                time_taken = end_time - start_time
                print(f"Congratulations! You have correctly guessed the word '{word}'.")
                print(f"Time Taken: {time_taken:.2f} seconds 🕔")

                # Updates statistics with a win
                WordGuesser.update_statistics("win", time_taken)

                # Show win streak
                with open("statistics.csv", "r") as file:
                    reader = csv.DictReader(file)
                    for row in reader:
                        print(f"Current Win Streak: {row["Current Win Streak"]}🔥\n")

                # If user wants to play again
                if WordGuesser.is_play_again():
                    return cls.start_game()
                else:
                    return main()

            # Prints the evaluated guess
            WordGuesser.evaluate_guess(guess, word)

            # Uses up an attempt
            attempts -= 1

            # If user runs out of guesses
            if attempts == 0:
                # Record end time
                end_time = time.time()
                time_taken = end_time - start_time
                # Prints out the losing message
                print(f"The word you were trying to guess was '{word}'. Nice try!")

                # Update statistics with a loss
                WordGuesser.update_statistics("lose", time_taken)

                # If user wants to play again
                if WordGuesser.is_play_again():
                    return cls.start_game()
                else:
                    return main()

            print(f"Attempts left: {attempts}\n")


    @classmethod
    def statistics(cls):
        choice = WordGuesser.view_statistics()
        # If player chooses to go back to main menu
        if choice == "1":
            return main()

        # If player chooses to reset statistics
        if choice == "2":
            # Verifies if user is meaning to reset statistics
            while True:
                answer = input("Are you sure you want to reset your statistics? [Y/N] ").strip().lower()
                if answer.startswith("y"):
                    WordGuesser.reset_statistics()
                    return cls.statistics()
                if answer.startswith("n"):
                    return cls.statistics()
                print("Y/N")

        # If player chooses to end programme
        elif choice == "3":
            WordGuesser.end_programme()
            return


    @classmethod
    def end_programme(cls):
        print("Ending programme...")
        time.sleep(1)
        f = Figlet(font="big")
        print(f.renderText('Thanks for playing!\n'))
        return


    @classmethod
    def how_to_play(cls):
        instructions = """
==========================
        HOW TO PLAY
==========================

a. Objective:
The objective of WordGuesser is to guess a secret word within a limited number of attempts by entering guesses of the same length.

b. Gameplay:
- Guessing:
    You will be prompted to enter a word with the specified number of letters.
    After each guess, you will receive feedback in the form of colored circles:
    🟢: Correct letter in the correct position.
    🟡: Correct letter, but in the wrong position.
    🔴: The letter is not in the word.

c. Winning or Losing:
- You win if you guess the word within the allowed number of attempts.
- If you run out of attempts, the secret word will be revealed, and you lose.

d. Tips:
- Use common words and vary your guesses to reveal the correct word faster!

e. Navigation:
- Restart the game or view your statistics at any point during the programme.
        """

        print(instructions)

        # Print options
        print("1: Back to main menu\n2: End programme\n")
        while True:
            option = input("Option: ")
            if option == "1":
                return main()
            if option == "2":
                return


    @classmethod
    def handle_exit(cls, input):
        if input == "/R" or input == "/RESTART":
            print("Restarting...")
            time.sleep(1)
            return WordGuesser.start_game()
        if input == "/Q" or input == "/QUIT":
            print("Quitting...")
            time.sleep(1)
            print(f"The word you were trying to guess was '{cls.generated}'. Nice try!")
            WordGuesser.update_statistics("lose")
            if WordGuesser.is_play_again():
                return WordGuesser.start_game()
            return main()


    @classmethod
    # For dramatic effect and better pacing
    def processing(cls):
        print("Processing...")
        time.sleep(1)
        return


# Validates user input
def get_int(s):
    # Valid number of letters of a word
    LENGTH = range(4, 13)
    while True:
        try:
            n = int(input(s))
        # If input is not an integer
        except ValueError:
            print("Not an integer")
            continue
        # If input is not a valid integer
        if n not in LENGTH:
            print("Invalid number of letters")
        else:
            return n


def main():
    # Start up prompt to ask the user for the next action
    option = WordGuesser.startup_menu()

    # If user chooses to start a game
    if option == "1":
        WordGuesser.start_game()

    # If player chooses to view their statistics
    elif option == "2":
        WordGuesser.statistics()

    # If player chooses to learn how to play
    elif option == "3":
        WordGuesser.how_to_play()

    # If player chooses to end programme
    elif option == "4":
        WordGuesser.end_programme()
        return


if __name__ == "__main__":
    main()
