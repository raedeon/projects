# WordGuesser
#### Video Demo: https://youtu.be/FfEtP90i7NI
#### Description:
WordGuesser is a fun command-line word guessing game inspired by Wordle! The goal is to guess a secret word within a limited number of attempts, with feedback provided through coloured indicators for correct, partially correct, and incorrect letters. It also tracks your gameplay statistics, including win streaks and fastest win times.

## Table of Contents
- [Features](#features)
- [Usage](#usage)
- [Files](#files)

## Features

### Game Options:
- **Startup Menu**: Choose from starting a new game, viewing statistics, reading "How to Play", or ending the programme.
- **Restart/Quit Options**: Players can restart (`/restart`) or quit (`/quit`) the game at any time.
- **Play Again**: Option to play again after each game.
- **Reset Statistics**: Players can reset all their statistics including win streaks and fastest win time.

### Gameplay:
- **Dynamic Word Length**: Select a word length between 4 and 12 letters.
- **Adaptive Attempts**: The number of attempts is dynamically calculated based on word length.
- **Feedback System**: Coloured circles indicate correctness:
  - 🟢: Correct letter and position.
  - 🟡: Correct letter, wrong position.
  - 🔴: Letter not in the word.
- **Hint System**: The game notifies you if your guess contains non-alphabet characters, if it is not in the dictionary, or if it has been used before.
- **Word Reveal**: If you lose, the correct word is revealed.
- **Letter Tracking**: Displays letters guessed correctly or incorrectly so far.
- **Remaining Attempts**: Shows how many attempts are left after each guess.

### Visuals and Design:
- **ASCII Art**: `pyfiglet` adds a polished look with dynamic ASCII text.
- **Organized Statistics**: Game stats are displayed using the `tabulate` module for clarity.

### Timing and Pacing:
- **Game Timer**: Tracks how fast the player guesses the secret word.
- **Game Pauses**: Introduces pauses for better pacing between guesses.
- **Processing Effect**: Adds a "Processing..." pause for suspense after each guess.

### Statistics Tracking:
- **Game Statistics**: Tracks total games played, total wins, win percentage, current win streak, longest win streak, and fastest win.
- **End-of-Game Feedback**: Displays win streak and time taken to guess the word after each win.

---

## Usage
- Select the number of letters for the word to guess (between 4 and 12).
- You will be allowed a number of attempts based on the length of the word.
- Enter guesses of the same length as the chosen word.
- Use the feedback (🟢🟡🔴) to refine your guesses:
  - 🟢: Correct letter in the correct position.
  - 🟡: Correct letter, but in the wrong position.
  - 🔴: The letter is not in the word.
- After each guess, you'll see a table of your previous guesses, with letters marked as correct, misplaced, or wrong.
- The system also displays lists of letters that are in and not in the word.
- You win by guessing the word correctly within the allowed attempts!
- Game statistics are automatically updated after each game and can be viewed in the main menu. These include:
  - Total games played
  - Total wins
  - Win percentage
  - Current win streak
  - Longest win streak
  - Fastest win time
- Restart or quit the game anytime by entering `/restart` or `/quit`.

---

## Files

### 1. `project.py`
- Contains the main game code, including word generation, guess evaluation, statistics tracking, and the main game loop.
- Handles the logic for starting a game, processing guesses, and updating player statistics.

### 2. `words.txt`
- A text file containing a dictionary of valid words.
- This file is used to both generate the secret word and validate user guesses.

### 3. `statistics.csv`
- Stores player statistics across sessions, including:
  - Total games played
  - Total wins
  - Win percentage
  - Current and longest win streaks
  - Fastest win (in seconds)
- Automatically updated after each game.

### 4. `requirements.txt`
- Lists the dependencies required to run the project, such as:
  - `pyfiglet`
  - `tabulate`

### 5. `test_project.py`
- Contains unit tests for the functions in `project.py`.
- Ensures that core functionality, such as word validation and statistics updating, works as expected.
