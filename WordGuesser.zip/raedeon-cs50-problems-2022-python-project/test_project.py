from project import WordGuesser
import pytest
import random


def test_valid_get_word():
    assert len(WordGuesser.get_word(4)) == 4
    assert len(WordGuesser.get_word(12)) == 12


# Test for invalid number of letters
def test_invalid_get_word():
    with pytest.raises(IndexError):
        len(WordGuesser.get_word(200))
    with pytest.raises(IndexError):
        len(WordGuesser.get_word(-1))


def test_valid_generate_attempts():
    # Round half to even rule
    assert(WordGuesser.generate_attempts(3)) == 4
    assert(WordGuesser.generate_attempts(5)) == 6
    assert(WordGuesser.generate_attempts(10)) == 8


# Tests if the number of letters that the attempts is based of is valid
def test_invalid_generate_attempts():
    with pytest.raises(ValueError):
        WordGuesser.generate_attempts(1)
    with pytest.raises(ValueError):
        WordGuesser.generate_attempts(0)
    with pytest.raises(ValueError):
        WordGuesser.generate_attempts(-1)


def test_is_valid_guess():
    # To generate cls.words
    random.seed(0)
    # The word generated is 'sades'
    word = WordGuesser.get_word(5)
    assert WordGuesser.is_valid_guess("hello", word) == True
    assert WordGuesser.is_valid_guess("cat", "world") == False
    assert WordGuesser.is_valid_guess("h3ll0", "hello") == False
    assert WordGuesser.is_valid_guess("abcde", "hello") == False


def test_is_correct_guess():
    assert WordGuesser.is_correct_guess("hello", "hello") == True
    assert WordGuesser.is_correct_guess("cat", "dog") == False
