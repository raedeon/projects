# TaskHero
#### Video Demo:  https://youtu.be/6h2Y0zDBpOo
#### Description:
My final project is a website called TaskHero. It aims to provide a simple and user-friendly platform where individuals are able to track and manage tasks that they may have on the daily.

## Table of Contents
- [Features](#features)
- [Usage](#usage)
- [Files](#files)

## Features
- User authentication
- Add, edit, sort and delete tasks
- Mark tasks as complete
- View task history
- Configure settings

## Usage
1. Open your web brower and go to 'https://bug-free-waffle-4xp57q5rw7jcqr-5000.app.github.dev'.
2. Register a new account or log in if you already have one
3. Start adding your tasks!

## Files
### 1. 'templates/layout.html'
- contains a navigation bar that can access either /register and /login or /add, /delete, /comepleted, /history, /settings and /logout depending on user authentication status
- contains the name of the site, 'TaskHero' on the top right corner

### 2. 'templates/login.html'
- login page
- users who are not logged in will be directed to this page
- users can log in with a username and a password given that they have an account
- has a navigation bar that contains the link to /register that renders register.html

### 3. 'templates/register.html'
- registration page
- users are able to register an account using a username and a password
- usernames are strictly unique
- passwords have the minimum requirement of at least 12 characters of which at least one is special and at least one is a digit
- after registration, users are redirected to /login that renders login.html

### 4. 'templates/index.html'
- main page
- displays a table of tasks, if any, that have the 'uncompleted' status
- displays a pie chart of tasks, if any, that have the 'uncompleted' status that is grouped by the type of the task
- if user does not have any tasks, the user can access /add in the navigation bar to add tasks
- if the user has any uncompleted tasks, the user can choose to edit it by clicking on the 'Edit' button, redirecting them to /edit
- if the user has any uncompleted tasks, the user can choose to complete it by clicking on the 'Complete' button, removing the task from /index and adding it into /completed
- users can sort the uncompleted tasks by clicking on the 'Sort by' dropdown

### 5. 'templates/add.html'
- page to add tasks
- users can indicate the type of task, the description of the task, the due date of the task and the priority of the task
- users can click on the 'Add' button to add the task

### 6. 'templates/delete.html'
- page to delete tasks
- users can indicate which tasks they want deleted by checking their respective checkboxes followed by clicking on the 'Delete' button, removing the task from the index page

### 7. 'templates/completed.html'
- page of completed tasks
- displays a table of tasks, if any, that have the 'completed' status
- displays a pie chart of tasks, if any, that have the 'completed' status that is grouped by the type of the task
- users can undo the completion of a task by clicking on the 'uncompleted' button, removing the task from /completed and adding it into /index
- users can sort the completed tasks by clicking on the 'Sort by' dropdown

### 8. 'templates/history.html'
- task history page
- displays a table of all tasks ever added
- displays a pie chart of tasks ever added that is grouped by the type of the task
- users can edit any task by clicking on the 'Edit' button
- users can complete or uncomplete any task by clicking on the 'Complete' or 'Uncomplete' buttons respectively depending on the task's status
- users can sort the history of tasks by clicking on the 'Sort by' dropdown

### 9. 'templates/settings.html'
- settings page
- users can change their username by clicking on the 'Change Username' button, redirecting them to /changeusername
- users can change their password by clicking on the 'Change password' button, redirecting them to /changepassword

### 10. 'templates/changeusername.html'
- page to change username
- users can change their username with password authentication

### 11. 'templates/changepassword.html'
- page to change password
- users can change their password with password authentication

### 12. 'templates/apology.html'
- apology page
- users are redirected to this page when an error occurs, loading an image with the top text being the error number and the bottom text being the cause of the error

### 13. 'static/error.jpg'
- contains the image used in apology.html

### 14. 'static/piechart.js'
- contains the JavaScript code required to load a piechart

### 15. 'static/styles.css'
- contains the stylesheet that beautifies the project

### 16. 'app.py'
- contains the Python code required to run the project

### 17. 'helpers.py'
- contains helper functions, namely the apology function and the password check function

### 18. 'logs.sql'
- contains the SQL code required to generate the SQL database of tasks

### 19. 'requirements.txt'
- contains the lists of dependencies the project needs

### 20. 'taskhero.db'
- contains the databases of the project, namely the users database and the tasks database
