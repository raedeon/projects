CREATE TABLE tasks (
    task_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    username TEXT NOT NULL,
    description TEXT NOT NULL,
    type TEXT NOT NULL,
    priority TEXT NOT NULL,
    status TEXT NOT NULL,
    datetime_added DATETIME NOT NULL,
    datetime_edited DATETIME,
    datetime_completed DATETIME,
    duedate DATETIME NOT NULL
);
